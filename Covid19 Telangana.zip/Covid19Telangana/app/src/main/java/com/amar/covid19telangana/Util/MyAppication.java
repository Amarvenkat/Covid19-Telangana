package com.amar.covid19telangana.Util;

import android.app.Application;

public class MyAppication extends Application {
}
