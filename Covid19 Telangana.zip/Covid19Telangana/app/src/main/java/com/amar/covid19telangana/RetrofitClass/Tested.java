package com.amar.covid19telangana.RetrofitClass;

public class Tested {


}
